<?php
namespace IEXBase\TronAPI\Exception;

class TronException extends \Exception {
    //
}
