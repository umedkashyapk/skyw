<?php
header("Access-Control-Allow-Origin: *");
Header('Access-Control-Allow-Headers: *'); //for allow any headers, insecure
header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
header("Access-Control-Allow-Headers: X-Requested-With");

class Reward extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        
        $key_data2 = $this->conn->runQuery('*','api_key',"key_type='session_encryption_key'");
        $this->session_encryption_key = $key_data2[0]->api_key;
    }
    
    
    public function index(){
       // $input_data = $this->conn->get_input();
       if(isset($_POST['u_id'])){
            $user_id = $_POST['u_id'];
            $user_detailss=$this->conn->runQuery('rank_id','users',"id='$user_id'");
            $my_rank_id=$user_detailss[0]->rank_id;
            
            
            $first_date = date('Y-m-d H:i:s',strtotime('first day of this month'));
            $last_date = date('Y-m-d H:i:s',strtotime('last day of this month'));
            $check_directs=$this->conn->runQuery('SUM(amount) as amts','transaction',"tx_type='income' and u_code='$userid' and date>='$first_date' and date<='$last_date'");  
            $total_income1=$check_directs[0]->amts;
                
            $community_buss=$this->business->community_business($userid,$first_date,$last_date);
            $total_community_inc=array_SUM($community_buss); 
            
            $plan_details = $this->conn->runQuery('rank,rank_reward,rank_income,id','plan',"id<=8");
            if($plan_details){
               
                $sr=1;
                foreach($plan_details as $plan_details1){
                    $rankid=$plan_details1->id;
                    $detailss = json_decode(json_encode($plan_details1),true);
                    $rank_details = $this->conn->runQuery('*','rank',"u_code='$user_id' and rank='$ranks'"); 
                    $rank_status=($my_rank_id>=$rankid  ? 'Achieved':'Pending');
                     
                    $detailss['Current_Month_Community']=$total_income1+$total_community_inc;
                    $detailss['status']=$rank_status;
                    $data[]=$detailss;
                    $details['data']= $data;
                 $sr++;    
                }
            }else{
                $details['data']= array();
            }
            
            $details['res']='success';
            $details['message']='';
            $result = $details;
            
        }else{
            
            $result['res']='error';
            $result['message']='This user does not have account.';
            $result['data']=array();
             
        }
        print_r(json_encode($result)); 
        
    }
	
	
	public function development_bonus(){
        
        //$input_data = $this->conn->get_input();
        if(isset($_POST['u_id'])){
            $user_id = $_POST['u_id'];
            $user_detailss=$this->conn->runQuery('development_rank_id','users',"id='$user_id'");
            $my_rank_id=$user_detailss[0]->development_rank_id;
            
            $plan_details = $this->conn->runQuery('id,gambit_direct,gambit_income,gambit_rank,gambit_reward','plan',"id<=5");
            if($plan_details){
                $sr=1;
                foreach($plan_details as $plan_details1){
                    $rankid=$plan_details1->id;
                    $detailss = json_decode(json_encode($plan_details1),true);
                 
                    $rank_status=($my_rank_id>=$rankid  ? 'Achieved':'Pending');
                     
                    $detailss['status']=$rank_status;
                    $data[]=$detailss;
                    $details['data']= $data;
                 $sr++;    
                }
            }else{
                $details['data']= array();
            }
            
            $details['res']='success';
            $details['message']='';
            $result = $details;
            
        }else{
            
            $result['res']='error';
            $result['message']='This user does not have account.';
            $result['data']=array();
             
        }
        print_r(json_encode($result)); 
        
    }
    
    
    public function mission_mall(){
        
        $input_data = $this->conn->get_input();
        if(isset($input_data['u_id'])){
            $user_id = $input_data['u_id'];
            
            $plan_details = $this->conn->runQuery('*','mission_mall',"1=1");
            if($plan_details){
                $sr=1;
                foreach($plan_details as $plan_details1){
                   
                    $detailss = json_decode(json_encode($plan_details1),true);
                    //$detailss['status']=$rank_status;
                    $data[]=$detailss;
                    $details['data']= $data;
                    $sr++;
                    
                }
            }else{
                $details['data']= array();
            }
            
            $plan_details2 = $this->conn->runQuery('*','member_income',"1=1");
            if($plan_details2){
                $sr1=1;
                foreach($plan_details2 as $plan_details11){
                   
                    $detailss22 = json_decode(json_encode($plan_details11),true);
                    //$detailss['status']=$rank_status;
                    $data22[]=$detailss22;
                    $details['member']= $data22;
                    $sr1++;
                    
                }
            }else{
                $details['member']= array();
            }
            
            $details['res']='success';
            $details['message']='';
            $result = $details;
            
        }else{
            
            $result['res']='error';
            $result['message']='This user does not have account.';
            $result['data']=array();
             
        }
        print_r(json_encode($result));
        
    }
    
    
    public function member(){
        
        $input_data = $this->conn->get_input();
        if(isset($input_data['u_id'])){
            $user_id = $input_data['u_id'];
            
            $plan_details = $this->conn->runQuery('*','member_income',"status=1 order by id desc limit 2");
            if($plan_details){
                $sr=1;
                foreach($plan_details as $plan_details1){
                   
                    $detailss = json_decode(json_encode($plan_details1),true);
                    //$detailss['status']=$rank_status;
                    $data[]=$detailss;
                    $details['data']= $data;
                    $sr++;
                    
                }
            }else{
                $details['data']= array();
            }
            
            $details['res']='success';
            $details['message']='';
            $result = $details;
            
        }else{
            
            $result['res']='error';
            $result['message']='This user does not have account.';
            $result['data']=array();
             
        }
        print_r(json_encode($result));
        
    }
	
	
	public function order(){
        
        $input_data = $this->conn->get_input();
        if(isset($input_data['u_id'])){
            $user_id = $input_data['u_id'];
            
            $plan_details = $this->conn->runQuery('tx_type,order_amount,order_bv,invoice_no,added_on','orders',"u_code='$user_id' order by id desc");
            if($plan_details){
                $sr=1;
                foreach($plan_details as $plan_details1){
                   
                    $detailss = json_decode(json_encode($plan_details1),true);
                    //$detailss['status']=$rank_status;
                    $data[]=$detailss;
                    $details['data']= $data;
                    $sr++;
                    
                }
            }else{
                $details['data']= array();
            }
            
            $details['res']='success';
            $details['message']='';
            $result = $details;
            
        }else{
            
            $result['res']='error';
            $result['message']='This user does not have account.';
            $result['data']=array();
             
        }
        print_r(json_encode($result));
        
    }
    
}